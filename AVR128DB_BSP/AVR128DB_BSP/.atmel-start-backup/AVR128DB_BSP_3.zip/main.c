#include <atmel_start.h>

int main(void)
{
	
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
		ENABLE_INTERRUPTS();
	/* Replace with your application code */
	while (1) {
	}
}
