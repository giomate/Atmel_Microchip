#include <atmel_start.h>

int main(void)
{
	int dummy=0;
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	dummy=1;
	/* Replace with your application code */
	while (1) {
		LED_0_toggle_level();
		_delay_ms(1000);
	}
}
