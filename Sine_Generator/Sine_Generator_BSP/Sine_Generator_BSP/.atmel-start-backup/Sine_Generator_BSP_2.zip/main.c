#include <atmel_start.h>

static  uint16_t  dac_value=0;
int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	dac_sync_enable_channel(&DAC_0, 0);
	bool dir=true;
	/* Replace with your application code */
	while (1) {
		for (uint16_t i = 0; i < 0x3ff; i++)
		{
			dac_value=dir?i:0x3ff-i;
			dac_sync_write(&DAC_0, 0, &dac_value, 1);
			delay_ms(10);
		}
		dir=!dir;
	}
}
