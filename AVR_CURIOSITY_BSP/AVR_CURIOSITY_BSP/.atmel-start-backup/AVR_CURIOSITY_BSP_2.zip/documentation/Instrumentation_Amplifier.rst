INTRODUCTION
=============
This is the START implementation of the Instrumentation Amplifier example from the Getting started with Analog Signal Conditioning (OPAMP) tech brief.OP0, OP1 and OP2 are configured together as an instrumentation amplifier. A sinusoidal signal is used as an input to the op amp, the sinusoidal signal is created using the DAC while the ADC is used to sample the output.Both the input and output to the op amp is sent over USART to the computer and can be plotted using the MPLAB Data Visualizer.

The application code is written for AVR128DB48, but is compatible with any AVRxxxDB48/AVRxxxDB64 device.   

PERIPHERALS INVOLVED
---------------------
    * Analog Signal Conditioning (OPAMP)
    * Analog to Digital Converter (ADC)
    * Digital to Analog Converter (DAC)
    * Real Time Clock (RTC)
    * Timer/Counter Type B (TCB)
    * Universal Synchronous and Asynchronous Receiver and Transmitter (USART)

RELATED DOCUMENTS / APPLICATION NOTES
--------------------------------------
    This application is described in the following tech brief:
        * Getting Started with Analog Signal Conditioning (OPAMP) (https://www.microchip.com/DS90003286)

SUPPORTED EVALUATION KIT
-------------------------
    * AVR128DB48 Curiosity Nano (https://www.microchip.com/DevelopmentTools/ProductDetails/PartNO/EV35L43A)

INTERFACE SETTINGS
-------------------
    * CPU CLK
        * 24 MHz
    * ADC
        * 10-bit resolution
        * Single
        * ADC input pin 10
        * Reference selected (VREF): VDD
        * PRESCALER: 12
    * DAC
        * Output buffer enabled
        * Reference selected (VREF): 2.048V
    * OPAMP
        * Triple:OP0-OP1-OP2 configured as a Instrumentation Amplifier
    * RTC 
        * Clock: Internal 32.768 KHz
        * PRESCALER: 32
        * Overflow interrupt enabled
    * TCB
        * Clock: CLK_PER
        * Mode: Periodic Interrupt
        * Capture or Timeout interrupt enabled
    * USART
        * No parity
        * 8-bit character size
        * 1 stop bit
        * 115200 baud-rate 
        * PB0 set as TX transmission pin

RUNNING THE DEMO
-----------------
1) Press DOWNLOAD SELECTED EXAMPLE in the example browser or click EXPORT PROJECT -> DOWNLOAD PACK from within START and save the .atzip
2) Import .atzip file into Atmel Studio 7 by clicking File->Import->Atmel Start Project
3) Build the application and program the device
4) Open the MPLAB Data Visualizer and load the work space called instrumentation-amplifier.json found in the .atzip folder
5) Sett the baud-rate to 115200 and start the serial communication
6) Go to Variable Streamers and select the COM port as input to Decoder1   
