/*
    \file   dac_application.c

    \brief  Instrumentation Amplifier Application using OPAMP

    (c) 2020 Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip software and any
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party
    license terms applicable to your use of third party software (including open source software) that
    may accompany Microchip software.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS
    FOR A PARTICULAR PURPOSE.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS
    SOFTWARE.
*/

#include "dac_application.h"

void sin_wave_table_init(void)
{
	for (uint16_t i = 0; i < SINE_WAVE_STEPS; i++) {
		sine_wave[i] = SINE_DC_OFFSET + SINE_AMPLITUDE * sin(i * M_2PI / SINE_WAVE_STEPS);
		;
	}
}

void DAC0_SineWaveTimer_enable(void)
{
	SINE_WAVE_TIMER.CTRLA |= TCB_ENABLE_bm;
}

ISR(SINE_WAVE_TIMER_vect)
{
	volatile static uint16_t sine_wave_index = 0;

	data_stream.diff_input = VDD_DIV_2_VOLTS - (sine_wave[sine_wave_index] << 1);
	DAC_0_set_output(sine_wave[sine_wave_index]);
	sine_wave_index++;
	sine_wave_index = sine_wave_index % SINE_WAVE_STEPS;

	SINE_WAVE_TIMER.INTFLAGS = TCB_CAPT_bm;
}
