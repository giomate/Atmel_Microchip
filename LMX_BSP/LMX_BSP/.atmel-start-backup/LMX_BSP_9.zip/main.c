#include <atmel_start.h>

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	timer_start(&TIMER_0);
	/* Replace with your application code */
	while (1) {
	}
}
